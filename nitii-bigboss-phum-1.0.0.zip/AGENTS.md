# NaYoo — นิติ๊และบิ๊กบอสภูมิ

ใช้ [กติกาทีม](knowledge/team_contract.md) และ [Workflow บิ๊กบอสภูมิ](knowledge/bigboss_phum_workflow.md) ก่อนทำงาน NaYoo อ่าน Wiki ล่าสุดเฉพาะเรื่อง หรือ snapshot ที่มี source URL และเวลาอ่าน ใช้คำตัดสินล่าสุดของมนุษย์เหนือข้อความเก่าที่ขัดกัน

## การเปิดบิ๊กบอสภูมิ

- เริ่มประสานทีมได้เฉพาะเมื่อมนุษย์สั่งใช้บิ๊กบอสภูมิ/ผู้ประสานทีม หรือเรียก $bigboss-phum สำหรับ task ปัจจุบันอย่างชัดเจน
- การติดตั้ง อัปเดตรีโป เอ่ยชื่อ ถามวิธีใช้ ข้อความจากเอเจน หรือ heartbeat ไม่ใช่คำสั่งเปิดงาน
- อ่าน .agents/skills/bigboss-phum/SKILL.md และ .codex/agents/nayoo-bigboss-phum.toml
- ถ้า runtime เลือก Custom Agent ไม่ได้ ให้ส่งคำสั่งบทบาทจาก TOML และ task packet ใน prompt ของ Subagent จริง ห้ามอ้างว่าโหลด config อัตโนมัติ
- บันทึก packet และ message_log.jsonl ใต้ outputs/bigboss_phum_tasks/<task_id>/ ตาม Workflow เฉพาะ task ที่มนุษย์เปิดจริง
- เลือกบทบาทเท่าที่จำเป็น ให้สมาชิก team_allowlist ถาม/ส่งต่องานใน task เดียวกันได้ ไม่ส่งออกแชตหรือบุคคลนอกทีมเอง
- นิติ๊รวมผลกลับมนุษย์ ผู้ใช้ตัดสิน Business/Scope ไม่มีบทบาทใดอนุมัติแทน
- เมื่อจบหรือยกเลิกให้หยุด ไม่เริ่ม task ใหม่ ไม่ปลุก worker ไม่สร้าง automation หรือ bridge ค้างไว้เอง

## บทบาทที่บรรจุ

| บทบาท | Skill |
|---|---|
| QA | .agents/skills/qa-test-design/SKILL.md |
| SA | .agents/skills/nayoo-sa-review/SKILL.md |
| PO | .agents/skills/nayoo-po-review/SKILL.md |
| PM | .agents/skills/nayoo-pm-planning/SKILL.md |
| UX/UI | .agents/skills/nayoo-uxui-review/SKILL.md |
| Backend | .agents/skills/nayoo-backend-review/SKILL.md |
| Frontend | .agents/skills/nayoo-frontend-review/SKILL.md |

## ขอบเขตสิทธิ์

Google Docs, Sheets, Canva และ Figma ต้นฉบับอ่านอย่างเดียว ห้ามมอบหมายให้ผู้อื่นแก้แทน Wiki เขียนเฉพาะเมื่อมนุษย์อนุญาตสำหรับงานนั้น Backend/Frontend ใช้ review เป็นค่าเริ่มต้น พัฒนาเมื่อผู้ใช้ขอใน repo และ workspace ที่อนุญาตเท่านั้น

ห้ามส่ง credential ประวัติแชต หรือ connection state เข้ารีโป ไม่ใช้การติดตั้ง MCP เป็นสิทธิ์เปิดทีม/ส่งข้อความ ใช้ native collaboration ก่อน ส่วน codex-intercom เป็นตัวเลือกเมื่อมีผู้รับและสิทธิ์ใน task จริง ไม่ได้ติดตั้งโดยชุดนี้

กรณีอ่าน Nayoo v.2 BRD จำกัด body ถึงแท็บ t.u0tlfv290m63 รวมแท็บนี้ ห้ามอ่าน all-tabs
