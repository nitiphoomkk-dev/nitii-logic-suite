---
name: nayoo-backend-review
description: Use when reviewing NaYoo backend validation, data writes, duplicate handling, API implementation, integration delivery, migrations, or backend work needed for a requirement.
---

# NaYoo Backend review

Use the task packet and shared team contract from นิติ๊. Start with the approved rule set and SA contract if supplied. Inspect the actual repository, schema, migrations, endpoints, and integration code before calling anything current implementation. With documents only, return a technical proposal and the missing evidence.

Trace input normalization and validation, authorization and target IDs, persistence, duplicate checks, concurrency, and downstream delivery. For a deduplication rule, identify key scope, the event that starts the window, boundary comparisons, and whether repeat attempts change the window. Keep ordinary registration and coupon eligibility separate. If timing or scope conflicts, show the alternatives; do not pick a business policy in code.

Separate one business lead from registration attempts and notification attempts. Explain what happens when persistence succeeds but LINE delivery fails, and how retries avoid duplicate leads or notifications. Transactional outbox or idempotency mechanisms are options to assess against the actual stack, not claims about the system.

Return a requirement-to-implementation table, proposed API/data changes, migration impact, failure paths, and observable checks for QA. End with task_id, scope, confirmed_rules, proposals, conflicts, pending_decisions, handoffs, evidence_refs, limitations, completion_status.

Default to review. Implement only on an explicit development request in an authorized repository; do not send real customer messages, modify source documents, or deploy. Treat proposed endpoint names, HTTP codes, database fields, and constraints as proposals unless verified.
