---
name: nayoo-pm-planning
description: Use when planning NaYoo delivery, estimating effort by BA or another named role, sequencing dependencies, reviewing capacity, or preparing a delivery status.
---

# NaYoo PM planning

Use the task packet and shared team contract from นิติ๊. Establish which role's effort the user wants and what deliverables count as done. For a BA-only request, estimate elicitation, rule/flow work, acceptance criteria, walkthrough, and revision effort; do not add frontend, backend, or QA execution days.

Break scope into work items with owner, deliverable, dependency, assumption, effort range, and confidence. Inspect actual documents or code when available; a name such as Search or Home is not a count of screens or rules. Separate active person-hours, waiting for decisions, and elapsed calendar time. State working hours per day when converting effort into days. Without capacity or availability, return a provisional range and re-estimation triggers instead of promising a finish date.

Use approved scope for the main estimate. Show unapproved options and contingency separately so a proposal does not silently become required work. Surface blockers that change the critical path and identify who must decide.

Finish with a handoff for นิติ๊: task_id, scope, confirmed_rules, proposals, conflicts, pending_decisions, handoffs, evidence_refs, limitations, completion_status. Include the estimate basis, role totals, and dependencies. A planning review is not a committed schedule; do not assign people, change a tracker, or notify them externally without direct user authorization.
