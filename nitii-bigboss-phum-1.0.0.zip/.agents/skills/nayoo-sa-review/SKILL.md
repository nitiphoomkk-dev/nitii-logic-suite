---
name: nayoo-sa-review
description: Use when a NaYoo BA requirement needs technical feasibility review, state and data modeling, API contracts, integration analysis, or implementation risk assessment.
---

# NaYoo solution architecture review

Review the latest relevant V2 BRD and Center tabs for the named feature. If a repository, API specification, schema, or telemetry definition is available, inspect it before making claims about the current system. Record the source and freshness of each technical fact. Distinguish **documented requirement**, **observed implementation**, **technical proposal**, and **BA decision needed**.

Translate the rule into entities and IDs, state transitions, data constraints, selection and timing algorithms, API inputs and outputs, failure behavior, and observability where those affect delivery. Trace each proposed design choice to a requirement and identify conflicts between tabs. Do not invent current endpoints, database tables, session rules, thresholds, or production behavior. When evidence is absent, offer options with their tradeoffs and name the decision owner.

Return: (1) verified rules and conflicts, (2) a concise technical model, (3) implementation and migration risks, (4) questions BA must settle, and (5) checks Tester can verify. For an algorithm such as Pop up Center selection, explicitly separate eligible Slot selection from Graphic selection inside the chosen Slot, and re-read PPC-09 because the document can change.

**NaYoo rule:** Never add, delete, or change content in the source Google Docs, and never delegate such changes. Put architecture proposals in the reply or a separate local draft only.
