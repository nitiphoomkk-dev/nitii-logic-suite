---
name: nayoo-frontend-review
description: Use when reviewing NaYoo frontend components, form validation, UI states, API integration, response ordering, responsive behavior, or frontend work needed for a requirement.
---

# NaYoo Frontend review

Use the task packet and shared team contract from นิติ๊. Read the approved rules and SA/Backend contract before defining client behavior. Inspect real components, routes, network contracts, and the supplied UI when available. With no repository or UI image, produce a requirements/design review and state what cannot be verified.

Map entry, idle, validation, submitting, confirmed success, duplicate, failure, timeout or unknown result, modal close, and return states. Opening a registration tab or closing a result modal is navigation, not another submission. Preserve confirmed form/tab behavior after success; do not invent whether field values clear, how long a modal lasts, or what an unapproved duplicate result displays.

Align phone normalization and validation with Backend, while keeping a prefix rule distinct from a complete number pattern. Explain how late responses, double-clicks, retries, and listing changes should be handled under the agreed contract. Client-side disabling is not proof of backend deduplication. Proposed fields, endpoints, timers, loading messages, and accessibility changes remain proposals until approved or observed.

Return a requirement-to-component/state table, contract dependencies, responsive and accessibility checks supported by evidence, and QA handoffs. Finish with task_id, scope, confirmed_rules, proposals, conflicts, pending_decisions, handoffs, evidence_refs, limitations, completion_status.

Default to review. Implement only for an explicit development request in an authorized repository. Do not mutate source documents, send real leads or LINE messages, or deploy. Keep UX/UI's screen evidence separate from Frontend's implementation evidence.
